import org.quartz.*;

/**
 * implementation AbstractGenericJob
 */
public class ObjectJob extends AbstractGenericJob {

	private JobDataMap data;
	private Thread me;

	/**
	 * 
	 * @param datamap
	 */
	public JobExecutable getExecutable(JobDataMap datamap) {
		// TODO - implement ObjectJob.getExecutable
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param datamap
	 */
	public JobExecutable getExecutable(JobDataMap datamap) {
		// TODO - implement ObjectJob.getExecutable
		throw new UnsupportedOperationException();
	}

}
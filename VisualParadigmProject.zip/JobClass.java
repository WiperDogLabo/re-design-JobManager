import org.quartz.*;

/**
 * Create job class.
 */
public interface JobClass {

	/**
	 * Get the job class name.
	 * @return jobClassName
	 */
	String getJobClassName();

	/**
	 * Get the concurrency that is set.
	 * @return concurrency number of job can execute.
	 */
	int getConcurrency();

	/**
	 * Set the maximum concurrency.
	 * @param concurrency
	 */
	void setConcurrency(int concurrency);

	/**
	 * Get the execution time can be continued when the job was run start
	 * Job past the execution duration is interrupt.
	 * @return maxRunTime
	 */
	long getMaxRunTime();

	/**
	 * Set the maximum execution duration
	 * @param maxRunTime
	 */
	void setMaxRunTime(long maxRunTime);

	/**
	 * Get the maximum waiting time of when the job can not be run at its scheduled time due to the limitation of the number of concurrent.
	 * @return maxWaitTime
	 */
	long getMaxWaitTime();

	/**
	 * Set the maximum waiting time.
	 * @param maxWaitTime
	 */
	void setMaxWaitTime(long maxWaitTime);

	/**
	 * Get the affiliation list.
	 * @return assignedList
	 */
	List<JobKey> getAssignedList();

	/**
	 * Add it to the Job class.
	 * @param key Key job
	 */
	void addJob(JobKey key);

	/**
	 * Delete a job from the job class.
	 * @param key Key job
	 */
	void deleteJob(JobKey key);

	/**
	 * Get the affiliation list.
	 * @return assignedList
	 */
	List<JobKey> getAssignedList();

	/**
	 * Add it to the Job class.
	 * @param key Key job
	 */
	void addJob(JobKey key);

	/**
	 * Delete a job from the job class.
	 * @param key Key job
	 */
	void deleteJob(JobKey key);

}
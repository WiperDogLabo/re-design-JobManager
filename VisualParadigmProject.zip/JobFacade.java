import org.quartz.*;

public interface JobFacade {

	/**
	 * Create the job class.
	 * @param jobClassName job class name
	 * @param concurrency number of job can execute
	 * @param maxWaitTime The maximum waiting time of when the job can not be run.
	 * @param maxRunTime Job past the acquisition and execution duration can continue to run time when the job was run start is interrupt.
	 */
	JobClass createJobClass(String jobClassName, int concurrency, long maxWaitTime, long maxRunTime);

	/**
	 * Assign job to job class.
	 * @param jobName The name of job
	 * @param jobClassName The class name of job.
	 */
	void assignJobClass(String jobName, String jobClassName);

	/**
	 * Remove job class.
	 * @param jobClassName The class name of job.
	 */
	void deleteJobClass(String jobClassName);

	/**
	 * Remove a job from the job classes.
	 * @param jobName The name of job.
	 * @param jobClassName The class name of job.
	 */
	void revokeJobClass(String jobName, String jobClassName);

	/**
	 * Creating job.
	 * @param name The name of job.
	 * @param cls The class name of job.
	 * @param data The data of job.
	 */
	JobDetail createJob(String name, Class<? extends Job> cls, JobDataMap data);

	/**
	 * 
	 * @param executable
	 */
	JobDetail createJob(JobExecutable executable);

	/**
	 * Remove job.
	 * @param job The detail of job.
	 */
	void removeJob(JobDetail job);

	/**
	 * Creating a trigger.
	 * @param name The name of job.
	 */
	Trigger createTrigger(String name);

	/**
	 * Assign a schedule to the Job.
	 * @param job The detail of job.
	 * @param trigger The trigger of job.
	 */
	void scheduleJob(JobDetail job, Trigger trigger);

	/**
	 * Delete trigger.
	 * @param trigger The trigger of job.
	 */
	void unscheduleJob(Trigger trigger);

	/**
	 * Get job detail.
	 * @param name The name of job.
	 */
	JobDetail getJob(String name);

	/**
	 * Get trigger of job.
	 * @param name The name of job.
	 */
	Trigger getTrigger(String name);

	/**
	 * Get class of job.
	 * @param name The name of job.
	 */
	JobClass getJobClass(String name);

	/**
	 * Pause scheduler.
	 */
	void pauseSchedule();

	/**
	 * Resume scheduler.
	 */
	void resumSchedule();

	/**
	 * Stop Job running.
	 * @param name The name of job want to interrupt.
	 */
	boolean interruptJob(String name);

	/**
	 * Get the job class from the job name.
	 * @param name The name of job.
	 */
	JobClass findJobClassForJob(String name);

	/**
	 * The number of jobs is running
	 * @param name The name of job.
	 */
	int getJobRunningCount(String name);

	/**
	 * Creating job.
	 * @param name The name of job.
	 * @param cls The class name of job.
	 * @param data The data of job.
	 */
	JobDetail createJob(String name, Class<? extends Job> cls, JobDataMap data);

	/**
	 * Remove job.
	 * @param job The detail of job.
	 */
	void removeJob(JobDetail job);

	/**
	 * Assign a schedule to the Job.
	 * @param job The detail of job.
	 * @param trigger The trigger of job.
	 */
	void scheduleJob(JobDetail job, Trigger trigger);

	/**
	 * Delete trigger.
	 * @param trigger The trigger of job.
	 */
	void unscheduleJob(Trigger trigger);

}
import JobClass.*;
import org.quartz.*;

public class JobClassImpl implements setMaxRunTime {

	private String jobClassName;
	private int concurrency;
	private long maxRunTime;
	private long maxWaitTime;
	private List<JobKey> assignedList;
	private JobFacadeImpl jobFacade;
	private JobFacadeImpl attribute;

	/**
	 * Get the job class name.
	 * @return jobClassName
	 */
	public String getJobClassName() {
		return this.jobClassName;
	}

	/**
	 * Get the concurrency that is set.
	 * @return concurrency number of job can execute.
	 */
	public int getConcurrency() {
		return this.concurrency;
	}

	/**
	 * Set the maximum concurrency.
	 * @param concurrency
	 */
	public void setConcurrency(int concurrency) {
		this.concurrency = concurrency;
	}

	/**
	 * Get the execution time can be continued when the job was run start
	 * Job past the execution duration is interrupt.
	 * @return maxRunTime
	 */
	public long getMaxRunTime() {
		return this.maxRunTime;
	}

	/**
	 * Set the maximum execution duration
	 * @param maxRunTime
	 */
	public void setMaxRunTime(long maxRunTime) {
		this.maxRunTime = maxRunTime;
	}

	/**
	 * Get the maximum waiting time of when the job can not be run at its scheduled time due to the limitation of the number of concurrent.
	 * @return maxWaitTime
	 */
	public long getMaxWaitTime() {
		return this.maxWaitTime;
	}

	/**
	 * Set the maximum waiting time.
	 * @param maxWaitTime
	 */
	public void setMaxWaitTime(long maxWaitTime) {
		this.maxWaitTime = maxWaitTime;
	}

	/**
	 * Get the affiliation list.
	 * @return assignedList
	 */
	public List<JobKey> getAssignedList() {
		// TODO - implement JobClassImpl.getAssignedList
		throw new UnsupportedOperationException();
	}

	/**
	 * Add it to the Job class.
	 * @param key Key job
	 */
	public void addJob(JobKey key) {
		// TODO - implement JobClassImpl.addJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Delete a job from the job class.
	 * @param key Key job
	 */
	public void deleteJob(JobKey key) {
		// TODO - implement JobClassImpl.deleteJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Get the affiliation list.
	 * @return assignedList
	 */
	public List<JobKey> getAssignedList() {
		// TODO - implement JobClassImpl.getAssignedList
		throw new UnsupportedOperationException();
	}

	/**
	 * Add it to the Job class.
	 * @param key Key job
	 */
	public void addJob(JobKey key) {
		// TODO - implement JobClassImpl.addJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Delete a job from the job class.
	 * @param key Key job
	 */
	public void deleteJob(JobKey key) {
		// TODO - implement JobClassImpl.deleteJob
		throw new UnsupportedOperationException();
	}

}
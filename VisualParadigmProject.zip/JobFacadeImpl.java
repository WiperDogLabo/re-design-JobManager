import org.quartz.*;

/**
 * process job
 */
public class JobFacadeImpl implements JobFacade {

	private Map<String, JobClass> jobClassMap;
	private Map<String, JobDetail> jobDetailMap;

	/**
	 * Create the job class.
	 * @param jobClassName job class name
	 * @param concurrency number of job can execute
	 * @param maxWaitTime The maximum waiting time of when the job can not be run.
	 * @param maxRunTime Job past the acquisition and execution duration can continue to run time when the job was run start is interrupt.
	 */
	public JobClass createJobClass(String jobClassName, int concurrency, long maxWaitTime, long maxRunTime) {
		// TODO - implement JobFacadeImpl.createJobClass
		throw new UnsupportedOperationException();
	}

	/**
	 * Assign job to job class.
	 * @param jobName The name of job
	 * @param jobClassName The class name of job.
	 */
	public void assignJobClass(String jobName, String jobClassName) {
		// TODO - implement JobFacadeImpl.assignJobClass
		throw new UnsupportedOperationException();
	}

	/**
	 * Remove job class.
	 * @param jobClassName The class name of job.
	 */
	public void deleteJobClass(String jobClassName) {
		// TODO - implement JobFacadeImpl.deleteJobClass
		throw new UnsupportedOperationException();
	}

	/**
	 * Remove a job from the job classes.
	 * @param jobName The name of job.
	 * @param jobClassName The class name of job.
	 */
	public void revokeJobClass(String jobName, String jobClassName) {
		// TODO - implement JobFacadeImpl.revokeJobClass
		throw new UnsupportedOperationException();
	}

	/**
	 * Creating job.
	 * @param name The name of job.
	 * @param cls The class name of job.
	 * @param data The data of job.
	 */
	public JobDetail createJob(String name, Class<? extends Job> cls, JobDataMap data) {
		// TODO - implement JobFacadeImpl.createJob
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param executable
	 */
	public JobDetail createJob(JobExecutable executable) {
		// TODO - implement JobFacadeImpl.createJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Remove job.
	 * @param job The detail of job.
	 */
	public void removeJob(JobDetail job) {
		// TODO - implement JobFacadeImpl.removeJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Creating a trigger.
	 * @param name The name of job.
	 */
	public Trigger createTrigger(String name) {
		// TODO - implement JobFacadeImpl.createTrigger
		throw new UnsupportedOperationException();
	}

	/**
	 * Assign a schedule to the Job.
	 * @param job The detail of job.
	 * @param trigger The trigger of job.
	 */
	public void scheduleJob(JobDetail job, Trigger trigger) {
		// TODO - implement JobFacadeImpl.scheduleJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Delete trigger.
	 * @param trigger The trigger of job.
	 */
	public void unscheduleJob(Trigger trigger) {
		// TODO - implement JobFacadeImpl.unscheduleJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Get job detail.
	 * @param name The name of job.
	 */
	public JobDetail getJob(String name) {
		// TODO - implement JobFacadeImpl.getJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Get trigger of job.
	 * @param name The name of job.
	 */
	public Trigger getTrigger(String name) {
		// TODO - implement JobFacadeImpl.getTrigger
		throw new UnsupportedOperationException();
	}

	/**
	 * Get class of job.
	 * @param name The name of job.
	 */
	public JobClass getJobClass(String name) {
		// TODO - implement JobFacadeImpl.getJobClass
		throw new UnsupportedOperationException();
	}

	/**
	 * Pause scheduler.
	 */
	public void pauseSchedule() {
		// TODO - implement JobFacadeImpl.pauseSchedule
		throw new UnsupportedOperationException();
	}

	/**
	 * Resume scheduler.
	 */
	public void resumSchedule() {
		// TODO - implement JobFacadeImpl.resumSchedule
		throw new UnsupportedOperationException();
	}

	/**
	 * Stop Job running.
	 * @param name The name of job want to interrupt.
	 */
	public boolean interruptJob(String name) {
		// TODO - implement JobFacadeImpl.interruptJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Get the job class from the job name.
	 * @param name The name of job.
	 */
	public JobClass findJobClassForJob(String name) {
		// TODO - implement JobFacadeImpl.findJobClassForJob
		throw new UnsupportedOperationException();
	}

	/**
	 * The number of jobs is running
	 * @param name The name of job.
	 */
	public int getJobRunningCount(String name) {
		// TODO - implement JobFacadeImpl.getJobRunningCount
		throw new UnsupportedOperationException();
	}

	/**
	 * Creating job.
	 * @param name The name of job.
	 * @param cls The class name of job.
	 * @param data The data of job.
	 */
	public JobDetail createJob(String name, Class<? extends Job> cls, JobDataMap data) {
		// TODO - implement JobFacadeImpl.createJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Remove job.
	 * @param job The detail of job.
	 */
	public void removeJob(JobDetail job) {
		// TODO - implement JobFacadeImpl.removeJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Assign a schedule to the Job.
	 * @param job The detail of job.
	 * @param trigger The trigger of job.
	 */
	public void scheduleJob(JobDetail job, Trigger trigger) {
		// TODO - implement JobFacadeImpl.scheduleJob
		throw new UnsupportedOperationException();
	}

	/**
	 * Delete trigger.
	 * @param trigger The trigger of job.
	 */
	public void unscheduleJob(Trigger trigger) {
		// TODO - implement JobFacadeImpl.unscheduleJob
		throw new UnsupportedOperationException();
	}

}
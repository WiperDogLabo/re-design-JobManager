import org.quartz.*;

/**
 * Abstract class implement InterruptableJob of quartz and do job.
 */
public class AbstractGenericJob implements InterruptableJob {

	private Thread me;
	private Logger logger;

	/**
	 * 
	 * @param context
	 */
	public Object doJob(JobExecutionContext context) throws Throwable {
		// TODO - implement AbstractGenericJob.doJob
		throw new UnsupportedOperationException();
	}

	/**
	 * set execution context fail
	 * @param context
	 */
	public void setFailed(JobExecutionContext context) {
		// TODO - implement AbstractGenericJob.setFailed
		throw new UnsupportedOperationException();
	}

	/**
	 * set job execution fail
	 * @param data
	 */
	public void setFailed(JobDataMap data) {
		// TODO - implement AbstractGenericJob.setFailed
		throw new UnsupportedOperationException();
	}

	/**
	 * setup suicide job
	 * @param context
	 */
	public JobDetail setSuicide(JobExecutionContext context) {
		// TODO - implement AbstractGenericJob.setSuicide
		throw new UnsupportedOperationException();
	}

	/**
	 * cancel suicide job
	 * @param context
	 * @param cancelJob
	 */
	public void cancelSuicide(JobExecutionContext context, JobDetail cancelJob) {
		// TODO - implement AbstractGenericJob.cancelSuicide
		throw new UnsupportedOperationException();
	}

	/**
	 * execute job
	 * @param context
	 */
	public void execute(JobExecutionContext context) {
		// TODO - implement AbstractGenericJob.execute
		throw new UnsupportedOperationException();
	}

	/**
	 * interrupt thread
	 */
	public void interrupt() {
		// TODO - implement AbstractGenericJob.interrupt
		throw new UnsupportedOperationException();
	}

	/**
	 * set job execution fail
	 * @param data
	 */
	public void setFailed(JobDataMap data) {
		// TODO - implement AbstractGenericJob.setFailed
		throw new UnsupportedOperationException();
	}

	/**
	 * cancel suicide job
	 * @param context
	 * @param cancelJob
	 */
	public void cancelSuicide(JobExecutionContext context, JobDetail cancelJob) {
		// TODO - implement AbstractGenericJob.cancelSuicide
		throw new UnsupportedOperationException();
	}


	/**
	 * Job for suicide.
	 * kill itself if overrunning.
	 * for individual running time setting.
	 */
	public class SuicideJob implements InterruptableJob {

		private String KEY_JOBKEY;
		private Logger logger;

		/**
		 * 
		 * @param context
		 */
		public void execute(JobExecutionContext context) {
			// TODO - implement SuicideJob.execute
			throw new UnsupportedOperationException();
		}

		public void interrupt() {
			// TODO - implement SuicideJob.interrupt
			throw new UnsupportedOperationException();
		}

	}

}
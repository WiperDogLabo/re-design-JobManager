import org.osgi.framework.*;

public class Activator implements BundleActivator {

	/**
	 * 
	 * @param context
	 */
	public void start(BundleContext context) {
		// TODO - implement Activator.start
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param context
	 */
	public void stop(BundleContext context) {
		// TODO - implement Activator.stop
		throw new UnsupportedOperationException();
	}

}